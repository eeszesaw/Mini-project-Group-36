#ifndef ADDCONTACT_HPP
#define ADDCONTACT_HPP

#include <string>

void addContact();  // Function to interact with user and add contact

#endif 
