#ifndef VIEWCONTACT_HPP
#define VIEWCONTACT_HPP

void viewContact();

#endif 
