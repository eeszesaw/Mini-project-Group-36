#ifndef SEARCHCONTACT_HPP
#define SEARCHCONTACT_HPP

void searchContact();

#endif 

