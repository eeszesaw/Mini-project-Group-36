#ifndef DELETECONTACT_HPP
#define DELETECONTACT_HPP

void deleteContact();

#endif 
