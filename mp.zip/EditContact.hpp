#ifndef EDITCONTACT_HPP
#define EDITCONTACT_HPP

void editContact();

#endif 
